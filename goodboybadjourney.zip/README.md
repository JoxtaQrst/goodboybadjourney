
 
# Good boy, bad Joruney
A Pico-8 game where you guide a special dog through a maze-like world in search of his owner.

## Overview
"Good boy, bad Joruney" is a top-down adventure game built on Pico-8. The game features a unique canine protagonist with an enchanted amulet that grants him invisibility—but only when he stands still.
